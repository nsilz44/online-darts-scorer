module.exports = {
  "extends": "standard",
  "rules": {
    "semi": [2, "always"],
    "indent": "off"
  }
};
